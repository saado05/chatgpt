# WHATSAPP CHATGPT
This is a source code to build a WhatsApp bot using OpenAI bot and Node.js. The bot is capable of understanding natural language and providing information on various topics. It can be used to answer questions, provide advice, and even have conversations with users. With this source code, you can create a powerful bot that can be used for a variety of purposes. <br>

NOTE: DON'T MESS UP WITH INDEX.JS FILE. <br>

# How to Install? 
$ git clone https://github.com/ShadowHackrs/Whatsapp-Bot <br>
$ cd whatsapp-chatgpt <br>
$ npm install <br>
$ node index.js <br>

Visit: https://shadowhackr.com <br>

# How to get OpenAI API?
Visit: https://beta.openai.com/account/api-keys
